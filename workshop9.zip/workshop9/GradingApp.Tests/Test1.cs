﻿namespace GradingApp.Tests;

[TestClass]
public class GradeTests
{
    [TestMethod]
    public void GetGrade_ScoreIs75_ReturnsDistinction()
    {
        int score = 75;
        string expected = "Distinction";
        string actual = GradeCalculator.GetGrade(score);
        Assert.AreEqual(expected, actual);
    }
    public void GetGrade_ScoreIs50_ReturnsPass()
    {
        int score = 50;
        string expected = "pass";
        string actual = GradeCalculator.GetGrade(score);
        Assert.AreEqual(expected, actual);
    }
    public void IsValidScore_ScoreIs20_ReturnsTrue()
    {
        int score = 20;
        bool expected = true;
        bool actual = GradeCalculator.IsValidScore(score);
        Assert.AreEqual(expected, actual);
    }
    public void IsValidScore_ScoreIs120_ReturnsFalse()
    {
        int score = 120;
        bool expected = false;
        bool actual = GradeCalculator.IsValidScore(score);
        Assert.AreEqual(expected, actual);
     }
}
