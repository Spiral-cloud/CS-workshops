﻿using System.Security.Cryptography.X509Certificates;

internal class Program
{
    private static void Main(string[] args)
    {
        // bool valid = false;
        // Console.WriteLine("Enter your score: ");
        // int score = int.Parse(Console.ReadLine()!);
        // valid = GradeCalculator.IsValidScore(score);
        // if (valid == true)
        // {
        //     string result = GradeCalculator.GetGrade(score);
        //  }
        Student s1 = new Student();
        s1.SetName("Bob"); s1.SetScore(38); s1.SetID(29980699);
        s1.PrintInfo();

    }

}
public class GradeCalculator()
{


    // public static bool IsValidScore(int score)
    // {
    //     if (score >= 0 && score <= 100)
    //     {
    //         Console.WriteLine("Valid score!");
    //         return true;
    //     }
    //     else
    //     {
    //         return false;
    //      }
    // }
    // public static string GetGrade(int score)
    // {
    //     if (score >= 70)
    //     {
    //         return "Distinction";
    //     }
    //     else if (score >= 40)
    //     {
    //         return "Pass";
    //     }
    //     else
    //     {
    //         return "Fail";
    //      }
    //  }

}
public class ExamBoard
{
    public static void ScoresModifier(Student[] students)
    {
        foreach(Student s in students)
        {
            
        }   
     }

 }
