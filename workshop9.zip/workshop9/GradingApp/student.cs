using System.Dynamic;
using System.Runtime.Intrinsics.Arm;

public class Student
{
    public string Name { get; set; }
    public int ID { get; set; }
    public int Score { get; set; } 

    

    public void SetName(string name)
    {
        Name = name;
    }

    public void SetID ( int id )
    {
        ID = id;
    }

    public void SetScore ( int score )
    {
        Score = score;
    }

    public void PrintInfo()
    {
        Console.WriteLine ($" Student { ID }: { Name } - Score : { Score } ") ;
    }
 }